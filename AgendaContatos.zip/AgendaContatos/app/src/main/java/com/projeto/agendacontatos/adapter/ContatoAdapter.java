package com.projeto.agendacontatos.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.projeto.agendacontatos.R;
import com.projeto.agendacontatos.database.Contato;
import java.util.List;

public class ContatoAdapter extends RecyclerView.Adapter<ContatoAdapter.ViewHolder> {
    private final List<Contato> contatos;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onEditClick(Contato contato);
        void onDeleteClick(Contato contato);
    }

    public ContatoAdapter(List<Contato> contatos, OnItemClickListener listener) {
        this.contatos = contatos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_contato, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contato contato = contatos.get(position);
        holder.txtNome.setText(contato.getNome());
        holder.txtTelefone.setText(contato.getTelefone());
        holder.imgEdit.setOnClickListener(v -> listener.onEditClick(contato));
        holder.imgDelete.setOnClickListener(v -> listener.onDeleteClick(contato));
    }

    @Override
    public int getItemCount() {
        return contatos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtNome, txtTelefone;
        ImageView imgEdit, imgDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNome = itemView.findViewById(R.id.txtNome);
            txtTelefone = itemView.findViewById(R.id.txtTelefone);
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }
    }
}
