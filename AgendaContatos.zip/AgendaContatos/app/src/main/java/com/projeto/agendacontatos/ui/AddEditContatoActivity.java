package com.projeto.agendacontatos.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.projeto.agendacontatos.R;
import com.projeto.agendacontatos.database.Contato;
import com.projeto.agendacontatos.database.ContatoDatabaseHelper;

public class AddEditContatoActivity extends AppCompatActivity {
    private EditText edtNome, edtTelefone;
    private ContatoDatabaseHelper dbHelper;
    private int contatoId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_contato);
        edtNome = findViewById(R.id.edtNome);
        edtTelefone = findViewById(R.id.edtTelefone);
        dbHelper = new ContatoDatabaseHelper(this);

        if (getIntent().hasExtra("id")) {
            contatoId = getIntent().getIntExtra("id", -1);
            loadContato();
        }
    }

    private void loadContato() {
        Contato contato = dbHelper.getAllContatos().stream()
                .filter(c -> c.getId() == contatoId)
                .findFirst()
                .orElse(null);

        if (contato != null) {
            edtNome.setText(contato.getNome());
            edtTelefone.setText(contato.getTelefone());
        }
    }

    public void salvarContato(View view) {
        String nome = edtNome.getText().toString();
        String telefone = edtTelefone.getText().toString();

        if (contatoId == -1) {
            dbHelper.addContato(nome, telefone);
        } else {
            dbHelper.updateContato(contatoId, nome, telefone);
        }
        finish();
    }
}
