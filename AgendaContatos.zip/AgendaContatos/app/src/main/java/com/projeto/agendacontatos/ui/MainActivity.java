package com.projeto.agendacontatos.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.projeto.agendacontatos.R;
import com.projeto.agendacontatos.adapter.ContatoAdapter;
import com.projeto.agendacontatos.database.Contato;
import com.projeto.agendacontatos.database.ContatoDatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ContatoAdapter adapter;
    private ContatoDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        dbHelper = new ContatoDatabaseHelper(this);
        loadContatos();
        fabAdd.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, AddEditContatoActivity.class)));
    }

    private void loadContatos() {
        List<Contato> contatos = dbHelper.getAllContatos();
        adapter = new ContatoAdapter(contatos, new ContatoAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(Contato contato) {
                Intent intent = new Intent(MainActivity.this, AddEditContatoActivity.class);
                intent.putExtra("id", contato.getId());
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(Contato contato) {
                dbHelper.deleteContato(contato.getId());
                loadContatos();
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadContatos();
    }
}
